/**
 * @author : devkimson
 * @description : 세팅변수는 이후에 변수자체로 설정값 받아서 사용해야하므로 이후 변경
 * @since : 2021.07.17
 * @namespace : com.devkimson.calendar
 * @site : https://devkimson.herokuapp.com/
 */


var _$ = {};
_$.isEmpty=(obj)=>{
	if(obj.constructor === Object
		&& Object.keys(obj).length === 0){
			return true;
		}
	return false;
}

var click = 0;


_$.fixed = {
	year:new Date().getFullYear(), // 고정 올해
	month:new Date().getMonth(), // 고정 이번달
	date:new Date().getDate() // 고정 오늘
}
var now = {
	$$year:new Date().getFullYear(),
	$$month:new Date().getMonth(),
	$$date:new Date().getDate()
}

var com;
if(!com) com = {};
if(!com.devkimson) com.devkimson = {};

com.devkimson.calendar = { // 기능들

	_id:"", // id값 객체내 변수로 저장시키기
	_settings:{},

	create:function(_id, _settings)
	{
		this._id=_id;
		this._settings=_settings||{};
		this.Calendar();
    },

	Timeset:function(__year, __month){ // 기본 시간 설정
			
		// time settings
		this.$time = __year!==undefined && __month!==undefined?
		new Date(__year, __month):new Date();
		this.$year = this.$time.getFullYear();
		this.$month = this.$time.getMonth();
		this.$day = this.$time.getDay(); // 오늘 요일 0~6
		this.$date = this.$time.getDate(); // 오늘 일 수
		this.$hour = this.$time.getHours();
		this.$minute = this.$time.getMinutes();
		this.$second = this.$time.getSeconds();
		this.$first = new Date(this.$year, this.$month, 1).getDay(); // 이번달 시작 요일
		this.$last = new Date(this.$year, this.$month+1, 0).getDate(); // 이번달 말일
		// console.log("now : " + this.$year + ":" + this.$month);
		// style settings
	},

	Init:function(){ // 초기화 작업
		var thead = this._id.getElementsByTagName('thead');
		var tbody = this._id.getElementsByTagName('tbody');
		if(thead.length==1 && tbody.length==1){
			thead[0].remove();
			tbody[0].remove();
		}
		var marker = document.getElementById("current");
		if(marker!=undefined){
			marker.remove();
			click=0;
		}
	},

	SetNav:function(){ // calendar navigator btn
		var span = document.createElement("span");
		
		var tr = document.createElement("tr");
		var td = document.createElement("td");
		// prev btn
		var btn = document.createElement("button");
		var node = document.createTextNode("prev");
		btn.setAttribute("class", "btn btn-secondary text-capitalize");
		btn.addEventListener("click", (event)=>{
			this.Prev();
		});
		btn.appendChild(node);
		span.appendChild(btn);

		// year select
		var span2 = document.createElement("span");
		var select = document.createElement("select");
		select.setAttribute("class", "form-select");
		select.addEventListener("change",(event)=>{
			now.$$year = parseInt(event.target.value);
			this.Calendar(now.$$year, now.$$month);
		});
		select.style.width="200px";
		for(var i=1999; i<2199; i++){
			var option = document.createElement("option");
			node = document.createTextNode(i);
			option.setAttribute("value", i);
			if(now.$$year==i) option.setAttribute("selected","true");
			option.appendChild(node);
			select.appendChild(option);
		}
		span2.appendChild(select)

		// month select
		select = document.createElement("select");
		select.setAttribute("class", "form-select");
		select.addEventListener("change",(event)=>{
			now.$$month = parseInt(event.target.value);
			this.Calendar(now.$$year, now.$$month);
		});
		select.style.width="100px";
		for(var i=0; i<12; i++){
			var option = document.createElement("option");
			node = document.createTextNode(i+1);
			option.setAttribute("value", i);
			if(now.$$month==i) option.setAttribute("selected","true");
			option.appendChild(node);
			select.appendChild(option);
		}
		span2.appendChild(select)
		// span2 attr
		span2.setAttribute("class","d-flex justify-content-center");
		span.appendChild(span2);

		// next btn
		btn = document.createElement("button");
		node = document.createTextNode("next");
		btn.setAttribute("class", "btn btn-secondary text-capitalize");
		btn.addEventListener("click",(event)=>{
			this.Next();
		});
		btn.appendChild(node);
		span.appendChild(btn);

		// span attr
		span.setAttribute("class", "d-flex justify-content-between");
		td.setAttribute("colspan","7");

		td.appendChild(span);
		tr.appendChild(td);
		return tr;
	},

	SetDay:function(){ // 요일 세팅
		var thead = document.createElement("thead");
		var tr = document.createElement("tr");
		var td = document.createElement("td");
		thead.appendChild(this.SetNav());
		var $etting = this._settings||{}; // or 연산자는 있는 값을 택해서 값을 저장시킴
		if(!$etting.table) $etting.table = {};

		if(this._id.getAttribute("class").indexOf("custom")==-1){ // 테이블 설정
			$etting.table.width!==undefined? // 테이블 셀별로 크기 조정
			(td.setAttribute("width",$etting.table.width),
			this._id.setAttribute("class", this._id.getAttribute("class") + " custom"))
			:"";

			$etting.table.color!==undefined?
			this._id.setAttribute("class", this._id.getAttribute("class") + " " + $etting.table.color):
			this._id.setAttribute("class", this._id.getAttribute("class") + " text-muted");

			$etting.table.bgColor!==undefined?
			this._id.setAttribute("class", this._id.getAttribute("class") + " " + $etting.table.bgColor):
			this._id.setAttribute("class", this._id.getAttribute("class") + "");

			$etting.table.padding!==undefined?
			this._id.style.padding=$etting.table.padding:
			this._id.style.padding="2rem";
			console.log(this._id.style.padding);

			$etting.table.collapse!==undefined?
			this._id.style.borderCollapse=$etting.table.collapse:
			this._id.style.borderCollapse="collapse";
			console.log(this._id.style.collapse);

			$etting.table.spacing!==undefined?
			this._id.style.borderSpacing=$etting.table.spacing:
			this._id.style.borderSpacing="0px";
			console.log(this._id.style.spacing);
		}

		for(var i=0; i<7; i++){
			var day = "일";
			if(i==1){ day = "월"; }
			if(i==2){ day = "화"; }
			if(i==3){ day = "수"; }
			if(i==4){ day = "목"; }
			if(i==5){ day = "금"; }
			if(i==6){ day = "토"; }
			td = document.createElement("td");
			var dayNode = document.createTextNode(day);
			td.appendChild(dayNode);
			// newM 삼항연산자는 괄호하고 컴마로 구분하여 여러 설정을 넣을수 있다.
			
			tr.setAttribute("class","fw-bold");
			tr.appendChild(td);
		}
		thead.appendChild(tr);
		this._id.appendChild(thead);
		
	},

	Calendar:function(__year, __month){ // 달력 만드는 기능
		this.Init(); // 초기화
		this.SetDay(); // 요일 세팅
		cal = new this.Timeset(now.$$year,now.$$month); // 인스턴스 생성
		var tbody = document.createElement("tbody");
		var tr = document.createElement("tr");

		for(var i=0; i<cal.$first; i++){ // fill Empty
			var td = document.createElement("td");
			var emptyNode = document.createTextNode("");
			td.appendChild(emptyNode);
			tr.appendChild(td);
		}

		for(var q=1; q<=cal.$last; q++){
			var td = document.createElement("td");
			var node = document.createTextNode(q);
			td.setAttribute("id", q);
			if(_$.fixed.date==q && _$.fixed.month==cal.$month && _$.fixed.year==cal.$year){
				// 달과 일수가 같을 때 오늘 표시
			td.setAttribute("class", "fw-bold");
			}
			td.addEventListener('click',(event)=>{
				var snum = event.target.textContent;
				this.Marker(snum);
			});
			td.appendChild(node);
			tr.appendChild(td);
			if((q+cal.$first)%7==0){
				tr = document.createElement("tr");
			}
			tbody.appendChild(tr);
		}

		if((cal.$first+cal.$last)%7!=0){ // 마지막 일이 딱 떨어지지 않을때 빈칸으로 채움
			for(var o=0; o<(7-(cal.$first+cal.$last)%7); o++){
				var td = document.createElement("td");
				var emptyNode = document.createTextNode("");
				td.appendChild(emptyNode);
				tr.appendChild(td);
			}
		}
		this._id.appendChild(tbody);
	},

	Prev:function(){ // 저번달
		now.$$month-=1;
		if(now.$$month==-1) {
			now.$$month=11;
			now.$$year--;
		}
		this.Calendar(now.$$year, now.$$month);
	},

	Next:function(){ // 다음달
		now.$$month+=1;
		if(now.$$month==12) {
			now.$$month=0;
			now.$$year++;
		}
		this.Calendar(now.$$year, now.$$month);
	},

	Marker:function($marker){ // 클릭 날짜 표시
		if(click==0){
			var mark = document.createElement("span");
			var node = document.createTextNode("");
			mark.appendChild(node);
			mark.setAttribute("id","current");
			mark.setAttribute("class", "position-absolute");
			document.body.appendChild(mark);
			click += 1;
		}
			
		var cur = document.getElementById("current");
		
		var ids = $marker==undefined?document.getElementById(now.$$date):document.getElementById($marker);
		var $top = $(ids).offset().top;
		var $left = $(ids).offset().left;
		var $height = $(ids).height();
		var $width = $(ids).width();
		var $etting = this._settings||{}; // or 연산자는 있는 값을 택해서 값을 저장시킴
		if(!$etting.marker) $etting.marker = {};
		if(!$etting.transition) $etting.transition = {};
		if(!$etting.attr) $etting.attr = {};

		// newM 새로운 사실
		// console.log($etting.marker.thick||"3px")을 뒤에두면 존재값 있고 없고에 따라
		// 존재값 혹은 디폴트값으로 부여된다.
		// 순서를 존재여부 값을 먼저 앞에 두고 디폴트값
		// ".5s cubic-bezier(1, 0, 0, 1)"

		var _mset = {
			transition: ($etting.marker.speed||".5s") + " " + ($etting.marker.bezier||"cubic-bezier(1, 0, 0, 1)"), // settable

			display: "inline-block",

			borderBottom: ($etting.marker.thick||"3px") // settable
			+ " " + ($etting.marker.style||"solid") 
			+ " " + ($etting.marker.color||"rgba(255, 173, 173, 0.5)"),

			width: $etting.marker.width||$width+"px", // settable

			height: $height+"px",

			top: "calc("+$top+"px + 1rem)",

			left: "calc("+($left)+"px + .5rem)"
		};
		
		cur.style.transition = _mset.transition; // settable
		cur.style.display = _mset.display;
		cur.style.borderBottom = _mset.borderBottom; // settable
		cur.style.width = _mset.width; // settable
		cur.style.height = _mset.height;
		cur.style.top = _mset.top;
		cur.style.left = _mset.left;
	}
}