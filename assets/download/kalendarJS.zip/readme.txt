1차 시험입니다.
사용방법은 블로그에 자세히 나와있습니다.

[ https://devkimson.herokuapp.com/board/list/blog/10 ]

1. table 태그에 id값을 주어 생성
<table id="kal" class="table"></table>

2. script에서
const kal = com.devkimson.calendar.create(document.getElementById('kal')||'kal',{
 	marker:{ // 클릭 위치 마커 관련 설정
 		color: "red", // color name or color code
 		// thick: "6px", // num
 		// style: "dashed", // value
 		speed: ".3s", // value
 		// bezier: "ease", // value
 		// width: "15px" // num
 	},
 	table:{ // 테이블 속성
 		// bgColor: "table-info",
 		color: "text-muted", // class name
 // 		width:"50px", // num
 // 		padding:"15px", // num
 // 		collapse: "separate", // value
 // 		spacing: ".5rem" // num
 	}
 });
or
const kal = com.devkimson.calendar.create(document.getElementById('kal')||'kal',{});
