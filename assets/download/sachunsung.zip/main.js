/**
 * 기본 세팅
 */

let lang = navigator.language.split("-")[0];
document.body.lang = lang;

// let getRandEmoji = function(){
//     let num = 0;
//     let arr = [];
//     for(let i=0; i<10; i++){
//         num = startEmoji + (Math.trunc(Math.random()*1733));
//         let emo = String.fromCodePoint(num);
//         arr.push(emo);
//     }
//     return arr;
// }


// let e2c = function(emoji){
//     return emoji.codePointAt();
// }

const startEmoji = 126976;
const emojis = ['🍊','🍡','🥜','🍲','🥑','🧈','🥮','🍤','🍙','🥄','🥠','🧂','🧇','🧀','🍵','🥣'];
let times = 1;
let tick = function(){
    let date = new Date();
    let h = date.getHours();
    let m = date.getMinutes();
    let s = date.getSeconds();
    document.getElementById('time').innerHTML = times;
    time = times;
    times++;
    // `${h>12?12+h:h}:${m}:${s}`;
}
let ranking = [];
// let scs = [];
let selected = [];
let done = [];
let all = [];

let score = 0;
let stage = 1;
let total_stage = 3;
let time = 0;

let ticks = setInterval(tick, 1000);

let lx = 3;
let ly = 4;
let ls = 6;
// let Node = function(node){
//     this.node = node;
// }

let createMap = function(lenX, lenY, size){
    this.show = (function(){
        let id = 0;
        let div = document.createElement('div');
        div.id = 'scs';
        let wrap = document.createElement('div');
        let span1 = document.createElement('span');
        let span2 = document.createElement('span');
        let span3 = document.createElement('span');
        span1.id='stage';
        span2.id='score';
        span3.id='time';
        span1.innerHTML = stage;
        span2.innerHTML = score;
        span3.innerHTML = time;
        span1.setAttribute("class", "badge bg-info");
        span2.setAttribute("class", "badge bg-secondary");
        span3.setAttribute("class", "badge bg-success");
        wrap.appendChild(span1);
        wrap.appendChild(span2);
        wrap.appendChild(span3);
        wrap.style.cssText = `
            margin-bottom: 1rem;
            display: flex;
            justify-content: space-around;
        `;
        div.appendChild(wrap);
        
        for (let i=0; i<lenX; i++){
            let row = document.createElement('div');
            row.classList.add('d-flex');
            row.dataset.x = i;

            for (let q=0; q<lenY; q++){
                let span = document.createElement('span');
                let name = emojis[Math.trunc(Math.random()*10)];
                // scs.push({id: new Node(i, q, name, size)});
                span.dataset.touch = 'none';
                span.dataset.x = i;
                span.dataset.y = q;
                span.classList.add('item');
                span.style.cssText = `
                    width: ${size}px;
                    height: ${size*1.8}px;
                    padding-bottom: 0.8rem;
                `;
                span.innerHTML = name;
                all.push(span);
                span.addEventListener('click',(ev)=>{
                    ev.target.classList.add('active');
                    selected.push(ev.target);
                    

                    // if(count == dall.length){
                    //     alert('게임 종료');
                    // }
                    if(selected.length>2){ // 선택 아이템
                        selected.forEach(x=>{
                            x.classList.remove('active');
                        });
                        selected = [];
                    } else if(selected.length == 2){
                        if(selected[0].dataset.x==selected[1].dataset.x && selected[0].dataset.y==selected[1].dataset.y){
                            selected.forEach(x=>{
                                x.classList.remove('active');
                            });
                            selected = [];
                        } else {
                            if(selected[0].innerHTML == selected[1].innerHTML){
                                selected.forEach(x=>{
                                    x.classList.add('hide');
                                });
                                done = [...done, ...selected]
                                selected = [];
                                score += 100;
                                span2.innerHTML = score;
                            } else {
                                selected.forEach(x=>{
                                    x.classList.remove('active');
                                });
                                selected = [];
                            }
                        }
                    }
                    let count = 0;
                    let dall = [];
                    dall = all.filter(x=>{
                        return !x.classList.contains('hide');
                    });
                    dall = dall.map(x=>{
                        return x.innerHTML;
                    });
                    for(let o of dall){
                        if(dall.indexOf(o)>-1){
                            if(dall.indexOf(o, dall.indexOf(o)+1)>-1){
                                // console.log('더 있음')
                            } else {
                                // console.log('더 없음')
                                count++;
                            }
                        }
                    }
                    if(count==dall.length){
                        if(stage>=total_stage){
                            new User('test', score, time);
                            ranking.forEach(x=>{
                                document.getElementById('ranking').innerHTML += `<li>${x.name} - ${x.score}점 - ${x.time}</li>`;
                            });
                            clearInterval(ticks);
                            alert('게임이 종료 되었습니다. 랭킹에 등재됩니다.');
                            selected = [];
                            done = [];
                            all = [];
                            time = 0;
                            times = 1;
                            score = 0;
                            stage = 0;
                            lx = 3;
                            ly = 4;
                            let btn = document.createElement('button');
                            let tarr = document.querySelector('#scs');
                            btn.id="restart";
                            btn.innerHTML = '다시 시작';
                            btn.setAttribute('class','btn btn-outline-info');
                            btn.style.cssText = `
                                position: absolute;
                                rigth: 0px;
                                top: 105%;
                            `;
                            btn.addEventListener('click',()=>{
                                let answer2 = confirm("다시 시작하시겠습니까?");
                                if(answer2){
                                    stage+=1;
                                    closeMap();
                                    createMap(lx, ly, 60);
                                    ticks = setInterval(tick, 1000);
                                    span1.innerHTML = stage;
                                }
                            });
                            document.querySelector('#scs').appendChild(btn);
                        } else {
                            setTimeout(()=>{
                                alert("매치되는 카드가 없어 게임을 종료합니다.");
                                let answer = confirm("다시 시작하시겠습니까?");
                                if(answer){
                                    stage+=1;
                                    if(stage<=total_stage){
                                        lx++;
                                        ly++;
                                    }
                                    closeMap();
                                    createMap(lx, ly, 50);
                                    span1.innerHTML = stage;
                                } else {
                                    if(document.getElementById('restart')==null){
                                        let btn = document.createElement('button');
                                        let tarr = document.querySelector('#scs');
                                        btn.id="restart";
                                        btn.innerHTML = '다시 시작';
                                        btn.setAttribute('class','btn btn-outline-info');
                                        btn.style.cssText = `
                                            position: absolute;
                                            rigth: 0px;
                                            top: 105%;
                                        `;
                                        btn.addEventListener('click',()=>{
                                            let answer2 = confirm("다시 시작하시겠습니까?");
                                            if(answer2){
                                                stage+=1;
                                                if(lx<7){
                                                    lx++;
                                                    ly++;
                                                }
                                                closeMap();
                                                createMap(lx, ly, 50);
                                                span1.innerHTML = stage;
                                            }
                                        });
                                        document.querySelector('#scs').appendChild(btn);
                                    }
                                }
                            }, 1000);
                        }
                    }
                });
                row.appendChild(span);
                id++;
            }

            div.appendChild(row);
        }
        document.body.appendChild(div);
        let ol = document.createElement('ol');
        ol.id="ranking";
        div.appendChild(ol);
        div.dataset.touch='none';
    })();
    // return new Array(lenX).fill(new Array(lenY).fill(0));
}

let User = function(name, score, time){
    this.name = name;
    this.score = score;
    this.time = time;
    // this.rank = ranking.indexOf(this);
    this.refresh = (()=>{
        ranking.push(this);
    })();
}

let closeMap = function(){
    selected = [];
    done = [];
    all = [];
    document.getElementById('scs').remove();
}

createMap(lx, ly, 50);

// emoji
// 126976 ~
// 128709
// 1733 개